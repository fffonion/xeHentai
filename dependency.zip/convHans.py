﻿  # coding:utf-8
import ZhConversion as zhconv
class convHans(object):
    def __init__(self, callback = None):
        self.dic_TW, self.dic_HK, self.dic_CN = self.mdic()
        # print len(self.dic_TW),len(self.dic_HK),len(self.dic_CN)
        self.callback = callback
        # self.CHS,self.CHT,self.TW,self.HK=0,1,2,3

    def toTW(self, str, encoding = 'utf-8'):
        return self._conv(str, self.dic_TW, encoding)

    def toHK(self, str, encoding = 'utf-8'):
        return self._conv(str, self.dic_HK, encoding)

    def toCN(self, str, encoding = 'utf-8'):
        return self._conv(str, self.dic_CN, encoding)

    # 生成转换字典
    def mdic(self):
        # 特殊用法覆盖
        # dict(a,**b)=a.update(b) return a
        return dict(zhconv.zh2Hant, **zhconv.zh2TW), \
            dict(zhconv.zh2Hant, **zhconv.zh2HK), \
            dict(zhconv.zh2Hans, **zhconv.zh2CN)
        '''table = mwikidict.split('\n')
        dic = dict()
        name = []
        for line in table:
            if not line:continue
            if line[0] == '$':
                #print line.split()[0][1:]
                name.append(dic)
                dic = dict()
            if line[0] == "'":
                word = line.split("'")
                dic[word[1]] = word[3]
        name[3].update(name[1]) # 简繁通用转换规则(zh2Hant)加上台湾区域用法(zh2TW)
        name[4].update(name[1]) # 简繁通用转换规则(zh2Hant)加上香港区域用法(zh2HK)
        name[5].update(name[2]) # 繁简通用转换规则(zh2Hans)加上大陆区域用法(zh2CN)'''

    def unilen(self, str):
        return len(unicode(str, 'utf-8'))

    def max_len(self, dict):
        max = 0
        for i in dict:
            dict[i] = dict[i].decode('utf-8')
            if len(dict[i]) > max:
                max = len(dict[i])
        return max

    def _conv(self, str, dict, encoding):
        '''
        TODO：dicmax情况下截取时，上次截取的尾巴要加到新词语的头上
        '''
        str = str.decode(encoding)  # .encode('utf-8')
        # print len(str),[str]
        for i in dict:
            str = str.replace(i, dict[i])
        '''pos=0
        offset=0
        line=''
        #标点及换行
        punct=[',','.',':',';','"','\'','?','!','。','，','：','；','“','”','！','？','‘','’',\
               '\n','\r','\t','\b']
        #最大单词长度
        #self.dic_TW_max,self.dic_HK_max,self.dic_CN_max=\
            #self.max_len(self.dic_TW),self.max_len(self.dic_HK),self.max_len(self.dic_CN)
        #print self.dic_TW_max,self.dic_HK_max,self.dic_CN_max
        dicmax=self.max_len(dict)
        #逆向最大匹配
        while pos<len(str):#必须每次重新计算
            pass'''
        return str

if __name__ == "__main__":
    def ca(a, b):
        print a, b
    a = "头发发展萝卜卜卦秒表表达"
    b = "大衛碧咸在寮國見到了布希 "
    c = "大卫·贝克汉姆在老挝见到了布什"
    import sys
    reload(sys)
    sys.setdefaultencoding('utf-8')
    h = convHans()
    # str_TW = h.toTW(a)
    # str_HK = h.toHK(c)
    # str_CN = h.toCN(b)
    print ('TW ' + h.toTW(a, encoding = 'utf-8'))
    print ('HK ' + h.toHK(c, encoding = 'utf-8'))
    print ('CN ' + h.toCN(b, encoding = 'utf-8'))
